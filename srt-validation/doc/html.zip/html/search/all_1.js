var searchData=
[
  ['description',['description',['../structerr_1_1ok.html#a7a4ac98392798457e8f74d022d0886f0',1,'err::ok::description()'],['../structerr_1_1file__not__exists.html#af877e97a851075f822e4ab079c85c01a',1,'err::file_not_exists::description()'],['../structerr_1_1unable__to__write.html#a6eb0092799a85d0646fd383378b27364',1,'err::unable_to_write::description()'],['../structerr_1_1invalid__file.html#aecd543249e7a86c641ba4f40045d5455',1,'err::invalid_file::description()']]]
];
