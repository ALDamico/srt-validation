var searchData=
[
  ['getendtime',['getEndTime',['../class_subtitle.html#a9245ebb9a13081e55c869cc72cc4587c',1,'Subtitle']]],
  ['getid',['getID',['../class_subtitle.html#ae2e5f53a634e9dbd3e8b2477e1f66176',1,'Subtitle']]],
  ['getmaxchars',['getMaxChars',['../class_subtitle.html#a64a269af616c7bc65542d9aa4188e2a5',1,'Subtitle']]],
  ['getmaxlines',['getMaxLines',['../class_subtitle.html#a62349aeda4220e51c5bbf4c2b686a73a',1,'Subtitle']]],
  ['getstarttime',['getStartTime',['../class_subtitle.html#a5ce120c0621b73be16b47afca24151ab',1,'Subtitle']]],
  ['gettrailingnewlinestate',['getTrailingNewLineState',['../class_subtitle.html#aea298b96c8caff8229a282f0dc32a730',1,'Subtitle']]]
];
