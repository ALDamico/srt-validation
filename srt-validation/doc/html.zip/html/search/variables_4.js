var searchData=
[
  ['id',['id',['../structerr_1_1ok.html#a2cd0925fceb8cb5d7a3f4aa65b86862f',1,'err::ok::id()'],['../structerr_1_1file__not__exists.html#a841e960ee82880b414c64c48f7e43a59',1,'err::file_not_exists::id()'],['../structerr_1_1unable__to__write.html#a2d757f80d3ac40a344146d3c20ffd4b3',1,'err::unable_to_write::id()'],['../structerr_1_1invalid__file.html#a8493c935aae3311f4f6c385530beb30a',1,'err::invalid_file::id()']]],
  ['invalid_5ffile',['invalid_file',['../namespaceerr.html#a73028ddd50280c8b41323d3a348d1495',1,'err']]]
];
