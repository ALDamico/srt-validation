var searchData=
[
  ['setendtime',['setEndTime',['../class_subtitle.html#a047bd2e888de5089bede9f1fc053862a',1,'Subtitle']]],
  ['setid',['setID',['../class_subtitle.html#ad08add4c1d85731de22117955023b8b2',1,'Subtitle']]],
  ['setmaxchars',['setMaxChars',['../class_subtitle.html#a9ce69056de54eaa680cb17e9124c0dd5',1,'Subtitle']]],
  ['setmaxlines',['setMaxLines',['../class_subtitle.html#a7eba5e807cd0ec38b5ede6bc31888393',1,'Subtitle']]],
  ['setstarttime',['setStartTime',['../class_subtitle.html#a09c4ab3a026b9c8cea358cf3552ff546',1,'Subtitle']]],
  ['settrailingnewlinestate',['setTrailingNewLineState',['../class_subtitle.html#a9799fe6c93f3ed95d5f21820560dca3b',1,'Subtitle']]],
  ['stringtotime',['stringToTime',['../_subtitle_8cpp.html#aa7822fee4f03e41b5b6abb84b1a67dbf',1,'Subtitle.cpp']]],
  ['subtitle',['Subtitle',['../class_subtitle.html#a5a88153fc62bf730bfb941fc18d09fd7',1,'Subtitle::Subtitle()'],['../class_subtitle.html#ad1d2554a288f762e9d9cf52e612b652f',1,'Subtitle::Subtitle(std::vector&lt; std::string &gt;)']]]
];
