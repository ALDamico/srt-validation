var searchData=
[
  ['subtitle',['Subtitle',['../class_subtitle.html',1,'']]]
];
