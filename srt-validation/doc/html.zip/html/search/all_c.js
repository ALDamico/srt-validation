var searchData=
[
  ['_7esubtitle',['~Subtitle',['../class_subtitle.html#a38038d39e954d1d0d4eac5cd74ffc040',1,'Subtitle']]]
];
