var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../class_subtitle.html#a62b3dcd9b2a5e7d441768c9d42e8c54d',1,'Subtitle::operator&lt;&lt;()'],['../class_time.html#a8295bca3f4381cb3ed59d37c933df962',1,'Time::operator&lt;&lt;()']]]
];
