var searchData=
[
  ['maxchars',['maxChars',['../class_subtitle.html#ac4a09db2d8e0fcae1d347026670caf51',1,'Subtitle']]],
  ['maxlines',['maxLines',['../class_subtitle.html#a047f41e0d6d6431cd132c2df7cb6c45c',1,'Subtitle']]],
  ['milliseconds',['milliseconds',['../class_time.html#a86dac976924149167b337305c2ed0efb',1,'Time']]],
  ['minutes',['minutes',['../class_time.html#a0d0705b2c63ff1f2a1cebdaf15e122ab',1,'Time']]]
];
