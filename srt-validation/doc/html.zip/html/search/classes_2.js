var searchData=
[
  ['ok',['ok',['../structerr_1_1ok.html',1,'err']]]
];
