var searchData=
[
  ['seconds',['seconds',['../class_time.html#a36bfeb8c7cf06fab7af0d5aad7b1a318',1,'Time']]],
  ['start_5ftime_5finitial_5fpos',['START_TIME_INITIAL_POS',['../_subtitle_8cpp.html#a862b2c63ca5b6bbc7746619a35d2a5ae',1,'Subtitle.cpp']]]
];
