var searchData=
[
  ['hours',['hours',['../class_time.html#a3842025178c6ff4a2c2149c1470cd6a0',1,'Time']]]
];
