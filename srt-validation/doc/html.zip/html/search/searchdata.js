var indexSectionsWithContent =
{
  0: "cdefghimostu",
  1: "fiostu",
  2: "e",
  3: "emst",
  4: "cgmost",
  5: "defhimosu",
  6: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Friends"
};

